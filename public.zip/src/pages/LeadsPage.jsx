import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';

const STATUSES = ['discovered', 'enriching', 'enriched', 'enrich_failed', 'no_website', 'exported', 'contacted'];
const RECOMMENDATIONS = ['SEND', 'SEND_WITH_CAUTION', 'VERIFY_MANUALLY', 'DO_NOT_SEND'];

function scoreColor(score) {
  if (score == null) return 'var(--text-faint)';
  if (score >= 80) return 'var(--teal)';
  if (score >= 60) return 'var(--amber)';
  return 'var(--rust)';
}

export default function LeadsPage() {
  const [params, setParams] = useSearchParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(null);
  const [search, setSearch] = useState(params.get('search') || '');

  const page = parseInt(params.get('page') || '1', 10);
  const status = params.get('status') || '';
  const recommendation = params.get('emailRecommendation') || '';
  const jobId = params.get('jobId') || '';

  async function load() {
    try {
      const query = Object.fromEntries(params.entries());
      const res = await api.listLeads({ ...query, page, limit: 25 });
      setData(res);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.toString()]);

  function updateParam(key, value) {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    next.set('page', '1');
    setParams(next);
  }

  function goPage(delta) {
    const next = new URLSearchParams(params);
    next.set('page', String(page + delta));
    setParams(next);
  }

  async function handleDelete(id) {
    if (!confirm('Delete this lead permanently?')) return;
    await api.deleteLead(id);
    load();
  }

  const exportParams = Object.fromEntries(params.entries());
  delete exportParams.page;

  return (
    <div className="page-enter">
      <div className="page-head">
        <div>
          <h1>Leads</h1>
          <p className={data ? '' : 'loading-dots'}>{data ? `${data.pagination.totalCount} total` : 'Loading'}</p>
        </div>
        <a className="btn btn--primary" href={api.exportCsvUrl(exportParams)}>
          Export CSV ↓
        </a>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        <div className="toolbar">
          <input
            type="search"
            placeholder="Search company, domain, email, city…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && updateParam('search', search)}
            style={{ flex: '1 1 240px', minWidth: 0 }}
          />
          <select value={status} onChange={(e) => updateParam('status', e.target.value)}>
            <option value="">All statuses</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <select value={recommendation} onChange={(e) => updateParam('emailRecommendation', e.target.value)}>
            <option value="">All recommendations</option>
            {RECOMMENDATIONS.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
          {jobId && (
            <button className="chip" onClick={() => updateParam('jobId', '')}>
              Job filter active ×
            </button>
          )}
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Company</th>
                <th>Email</th>
                <th>City</th>
                <th>Keyword</th>
                <th>Status</th>
                <th>Score</th>
                <th>Recommendation</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {data?.leads.map((lead) => (
                <>
                  <tr
                    key={lead._id}
                    style={{ cursor: 'pointer' }}
                    onClick={() => setExpanded(expanded === lead._id ? null : lead._id)}
                  >
                    <td>{lead.companyName}</td>
                    <td className="mono">{lead.primaryEmail || <span className="text-faint">—</span>}</td>
                    <td>{lead.city}</td>
                    <td className="text-dim">{lead.matchedKeyword}</td>
                    <td className="text-dim">{lead.status}</td>
                    <td className="mono" style={{ color: scoreColor(lead.emailVerificationScore) }}>
                      {lead.emailVerificationScore ?? '—'}
                    </td>
                    <td className="text-dim">{lead.emailRecommendation || '—'}</td>
                    <td>
                      <button
                        className="btn btn--sm btn--danger"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(lead._id);
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                  {expanded === lead._id && (
                    <tr key={lead._id + '-detail'}>
                      <td colSpan={8} style={{ background: 'var(--bg-panel-raised)' }}>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 24, fontSize: 12.5 }}>
                          <div>
                            <strong>Website</strong>
                            <br />
                            <a href={lead.website} target="_blank" rel="noreferrer" className="mono">
                              {lead.website || '—'}
                            </a>
                          </div>
                          <div>
                            <strong>Phone</strong>
                            <br />
                            <span className="mono">{lead.phone || '—'}</span>
                          </div>
                          <div>
                            <strong>Address</strong>
                            <br />
                            {lead.address || '—'}
                          </div>
                          <div>
                            <strong>Primary contact</strong>
                            <br />
                            {lead.primaryContactName
                              ? `${lead.primaryContactName} — ${lead.primaryContactTitle || ''}`
                              : '—'}
                          </div>
                          <div>
                            <strong>Notes</strong>
                            <br />
                            {lead.enrichmentNotes || '—'}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
          {data && data.leads.length === 0 && (
            <div className="empty-state">
              <div className="empty-state__glyph">∅</div>
              No leads match these filters yet.
            </div>
          )}
        </div>

        {data && (
          <div className="pagination">
            <button className="btn btn--sm" disabled={page <= 1} onClick={() => goPage(-1)}>
              ← Prev
            </button>
            Page {data.pagination.page} / {data.pagination.totalPages}
            <button className="btn btn--sm" disabled={page >= data.pagination.totalPages} onClick={() => goPage(1)}>
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
