import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import StatusBadge from '../components/StatusBadge.jsx';
import ProgressBar from '../components/ProgressBar.jsx';
import LogFeed from '../components/LogFeed.jsx';
import { api } from '../api.js';
import { getSocket } from '../socket.js';

const ACTIVE = ['queued', 'discovering', 'enriching', 'verifying', 'stopping'];

export default function JobDetailPage() {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [error, setError] = useState(null);
  const [logs, setLogs] = useState([]);
  const [stopping, setStopping] = useState(false);
  const pollRef = useRef(null);

  useEffect(() => {
    let mounted = true;

    async function load() {
      try {
        const { job } = await api.getJob(id);
        if (!mounted) return;
        setJob(job);
        setLogs((prev) => (prev.length ? prev : job.logs || []));
      } catch (err) {
        if (mounted) setError(err.message);
      }
    }
    load();

    const socket = getSocket();
    socket.emit('job:join', id);

    const onEvent = (payload) => {
      if (payload.jobId !== id) return;
      if (payload.type === 'log') {
        setLogs((prev) => [...prev, payload.data]);
      } else if (payload.type === 'status') {
        setJob((prev) => (prev ? { ...prev, status: payload.data.status } : prev));
      } else if (payload.type === 'progress') {
        setJob((prev) => (prev ? { ...prev, progress: payload.data.progress } : prev));
      } else if (payload.type === 'discover:lead') {
        setJob((prev) =>
          prev
            ? {
                ...prev,
                progress: {
                  ...prev.progress,
                  discover: { ...prev.progress.discover, newLeads: payload.data.newLeads },
                },
              }
            : prev,
        );
      } else if (payload.type === 'enrich:lead') {
        setJob((prev) =>
          prev
            ? {
                ...prev,
                progress: {
                  ...prev.progress,
                  enrich: {
                    ...prev.progress.enrich,
                    processed: payload.data.completed,
                    total: payload.data.total,
                  },
                },
              }
            : prev,
        );
      } else if (payload.type === 'verify:lead') {
        setJob((prev) =>
          prev
            ? {
                ...prev,
                progress: {
                  ...prev.progress,
                  verify: {
                    ...prev.progress.verify,
                    processed: payload.data.completed,
                    total: payload.data.total,
                  },
                },
              }
            : prev,
        );
      }
    };
    socket.on('job:event', onEvent);

    // Poll as a fallback in case the socket connection drops.
    pollRef.current = setInterval(load, 6000);

    return () => {
      mounted = false;
      socket.emit('job:leave', id);
      socket.off('job:event', onEvent);
      clearInterval(pollRef.current);
    };
  }, [id]);

  async function handleStop() {
    setStopping(true);
    try {
      await api.stopJob(id);
    } catch (err) {
      setError(err.message);
    } finally {
      setStopping(false);
    }
  }

  if (error) return <div className="error-banner">{error}</div>;
  if (!job) return <p className="text-dim loading-dots">Loading</p>;

  const p = job.progress || {};
  const isActive = ACTIVE.includes(job.status);

  return (
    <div className="page-enter">
      <div className="page-head">
        <div>
          <h1>{job.name}</h1>
          <p className="mono">
            {job.keywords.join(', ')} — {job.cities.join(', ')}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <StatusBadge status={job.status} />
          {isActive && job.status !== 'stopping' && (
            <button className="btn btn--danger btn--sm" onClick={handleStop} disabled={stopping}>
              {stopping ? 'Stopping…' : 'Stop run'}
            </button>
          )}
          <Link className="btn btn--sm" to={`/leads?jobId=${job._id}`}>
            View leads →
          </Link>
        </div>
      </div>

      {job.error && <div className="error-banner">{job.error}</div>}

      <div className="grid-2">
        <div className="panel">
          <p className="panel__title">Pipeline progress</p>

          <PhaseRow
            label="1. Discover"
            active={job.status === 'discovering'}
            done={p.discover?.combosTotal > 0 && p.discover?.combosProcessed >= p.discover?.combosTotal}
            value={p.discover?.combosProcessed || 0}
            total={p.discover?.combosTotal || 0}
            detail={`${p.discover?.newLeads || 0} new leads found`}
          />
          <PhaseRow
            label="2. Enrich"
            active={job.status === 'enriching'}
            done={job.status === 'verifying' || job.status === 'completed'}
            value={p.enrich?.processed || 0}
            total={p.enrich?.total || 0}
            detail={`${p.enrich?.enriched || 0} enriched · ${p.enrich?.noWebsite || 0} no site · ${p.enrich?.failed || 0} failed`}
          />
          <PhaseRow
            label="3. Verify"
            active={job.status === 'verifying'}
            done={job.status === 'completed'}
            value={p.verify?.processed || 0}
            total={p.verify?.total || 0}
            detail={`${p.verify?.valid || 0} valid · ${p.verify?.catchAll || 0} catch-all · ${p.verify?.invalid || 0} invalid`}
          />
        </div>

        <div className="panel">
          <p className="panel__title">Live feed</p>
          <LogFeed lines={logs} live={isActive} />
        </div>
      </div>
    </div>
  );
}

function PhaseRow({ label, active, done, value, total, detail }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
        <span style={{ fontWeight: 600, color: active ? 'var(--amber)' : done ? 'var(--teal)' : 'var(--text-dim)' }}>
          {label}
        </span>
        <span className="mono text-faint">
          {total > 0 ? `${value}/${total}` : active ? 'running…' : done ? 'done' : 'pending'}
        </span>
      </div>
      <ProgressBar value={value} total={total || (done ? 1 : 0)} />
      <div className="mono text-faint" style={{ fontSize: 11, marginTop: 5 }}>
        {detail}
      </div>
    </div>
  );
}
