import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import StatusBadge from '../components/StatusBadge.jsx';
import { api } from '../api.js';

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function JobsPage() {
  const [jobs, setJobs] = useState(null);
  const [error, setError] = useState(null);

  async function load() {
    try {
      const { jobs } = await api.listJobs();
      setJobs(jobs);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="page-enter">
      <div className="page-head">
        <div>
          <h1>Runs</h1>
          <p>Every discovery run started from the dashboard, live and historical.</p>
        </div>
        <Link to="/" className="btn btn--primary">
          + New run
        </Link>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="panel">
        {jobs === null && <p className="text-dim loading-dots">Loading</p>}
        {jobs && jobs.length === 0 && (
          <div className="empty-state">
            <div className="empty-state__glyph">∅</div>
            No runs yet. Start one from the New run tab.
          </div>
        )}
        {jobs &&
          jobs.map((job) => (
            <Link to={`/jobs/${job._id}`} className="card-link" key={job._id}>
              <div className="job-card">
                <div>
                  <div className="job-card__name">{job.name}</div>
                  <div className="job-card__meta">
                    {job.keywords.length} keyword(s) × {job.cities.length} location(s) · target{' '}
                    {job.target} · started {timeAgo(job.createdAt)}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span className="mono text-dim" style={{ fontSize: 12 }}>
                    {job.progress?.discover?.newLeads ?? 0} found
                  </span>
                  <StatusBadge status={job.status} />
                </div>
              </div>
            </Link>
          ))}
      </div>
    </div>
  );
}
