import { useEffect, useRef } from 'react';

function fmtTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour12: false });
}

export default function LogFeed({ lines, live }) {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [lines.length]);

  return (
    <div className="feed" ref={ref}>
      {lines.length === 0 && <div className="feed__line text-faint">Waiting for activity…</div>}
      {lines.map((l, i) => (
        <div className={`feed__line feed__line--${l.level || 'info'}`} key={i}>
          <span className="feed__ts">{fmtTime(l.ts)}</span>
          <span>{l.message}</span>
        </div>
      ))}
      {live && (
        <div className="feed__line">
          <span className="feed__ts">{fmtTime(Date.now())}</span>
          <span className="feed__cursor" />
        </div>
      )}
    </div>
  );
}
