const LIVE = ['discovering', 'enriching', 'verifying', 'stopping'];
const OK = ['completed'];
const BAD = ['failed'];

const LABELS = {
  queued: 'Queued',
  discovering: 'Discovering',
  enriching: 'Enriching',
  verifying: 'Verifying',
  completed: 'Completed',
  failed: 'Failed',
  stopping: 'Stopping',
  stopped: 'Stopped',
};

export default function StatusBadge({ status }) {
  const cls = LIVE.includes(status)
    ? 'badge--live'
    : OK.includes(status)
      ? 'badge--ok'
      : BAD.includes(status)
        ? 'badge--bad'
        : 'badge--idle';
  return (
    <span className={`badge ${cls}`}>
      <span className="badge__dot" />
      {LABELS[status] || status}
    </span>
  );
}
