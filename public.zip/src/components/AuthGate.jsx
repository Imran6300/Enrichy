import { useState, useEffect } from 'react';
import { setStoredApiKey, getStoredApiKey, verifyApiKey } from '../auth.js';

/**
 * Gates the entire dashboard behind a single API key prompt.
 *
 * This intentionally does not implement multi-user accounts — see
 * src/middleware/auth.js on the backend for why a single shared secret is
 * the right amount of auth for a self-hosted, single-operator tool. This
 * component's only job is: don't render the app until a *valid* key is
 * stored, and give a clear error if the typed key is wrong.
 */
export default function AuthGate({ children }) {
  const [checking, setChecking] = useState(true);
  const [authed, setAuthed] = useState(false);
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const existing = getStoredApiKey();
    if (!existing) {
      setChecking(false);
      return;
    }
    verifyApiKey(existing)
      .then((ok) => {
        setAuthed(ok);
        if (!ok) setStoredApiKey('');
      })
      .finally(() => setChecking(false));
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const ok = await verifyApiKey(input.trim());
      if (ok) {
        setStoredApiKey(input.trim());
        setAuthed(true);
      } else {
        setError('That key was rejected by the server. Double-check API_KEY in your .env.');
      }
    } catch (err) {
      setError(err.message || 'Could not reach the API server.');
    } finally {
      setSubmitting(false);
    }
  }

  if (checking) {
    return <div className="authgate authgate--checking">Checking session…</div>;
  }

  if (authed) {
    return children;
  }

  return (
    <div className="authgate">
      <form className="authgate__card" onSubmit={handleSubmit}>
        <div className="brand authgate__brand">
          <div className="brand__mark">
            <img src="/logo.png" alt="Enrichly" />
          </div>
          <div className="brand__text">
            <span className="brand__title">Enrichly</span>
            <span className="brand__sub">Console v2</span>
          </div>
        </div>
        <label className="authgate__label" htmlFor="apiKey">
          API key
        </label>
        <input
          id="apiKey"
          type="password"
          autoFocus
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste the API_KEY from your server's .env"
          className="authgate__input"
        />
        {error && <div className="authgate__error">{error}</div>}
        <button type="submit" className="authgate__submit" disabled={submitting || !input.trim()}>
          {submitting ? 'Checking…' : 'Unlock dashboard'}
        </button>
        <p className="authgate__hint">
          This key lives only in this browser's session storage — it's never stored anywhere
          else. Find it in the <code>API_KEY</code> value of the server's <code>.env</code> file.
        </p>
      </form>
    </div>
  );
}
