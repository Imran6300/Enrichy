import { useEffect, useState } from 'react';
import { NavLink, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import NewJobPage from './pages/NewJobPage.jsx';
import JobsPage from './pages/JobsPage.jsx';
import JobDetailPage from './pages/JobDetailPage.jsx';
import LeadsPage from './pages/LeadsPage.jsx';
import { clearAuth } from './auth.js';
import { resetSocket } from './socket.js';

function handleLogout() {
  resetSocket();
  clearAuth();
  window.location.reload();
}

function NavItem({ to, icon, label, end, onNavigate }) {
  return (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      className={({ isActive }) => `nav__link${isActive ? ' active' : ''}`}
    >
      <span className="nav__icon">{icon}</span>
      {label}
    </NavLink>
  );
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  // Close the mobile nav drawer whenever the route changes.
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <div className="shell">
      <aside className={`sidebar${menuOpen ? ' sidebar--open' : ''}`}>
        <div className="sidebar__head">
          <div className="brand">
            <div className="brand__mark">
              <img src="/logo.png" alt="Enrichly" />
            </div>
            <div className="brand__text">
              <span className="brand__title">Enrichly</span>
              <span className="brand__sub">Console v2</span>
            </div>
          </div>

          <button
            type="button"
            className="sidebar__menu-btn"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
          >
            {menuOpen ? (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </svg>
            )}
          </button>
        </div>

        <div className="sidebar__drawer">
          <nav className="nav">
            <NavItem to="/" end icon="+" label="New run" onNavigate={() => setMenuOpen(false)} />
            <NavItem to="/jobs" icon="≡" label="Runs" onNavigate={() => setMenuOpen(false)} />
            <NavItem to="/leads" icon="◎" label="Leads" onNavigate={() => setMenuOpen(false)} />
          </nav>

          <div className="sidebar__footer">
            Self-hosted discovery, enrichment
            <br />
            &amp; verification engine.
            <br />
            No third-party API keys required.
            <br />
            <button type="button" className="sidebar__logout" onClick={handleLogout}>
              Lock dashboard
            </button>
          </div>
        </div>
      </aside>

      <main className="main">
        <Routes>
          <Route path="/" element={<NewJobPage />} />
          <Route path="/jobs" element={<JobsPage />} />
          <Route path="/jobs/:id" element={<JobDetailPage />} />
          <Route path="/leads" element={<LeadsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
